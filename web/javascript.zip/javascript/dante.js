window.addEventListener('DOMContentLoaded',init,false);
 
function init() {
    document.getElementsByTagName("button")[0].addEventListener('click', show_hide, false);
}
 
function show_hide() {
    var element = document.getElementById("paragraphToToggle");
    if (element.style.display == "none") {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
}